Upload all files together. index.html is the home page. Menu links open separate HTML pages.
