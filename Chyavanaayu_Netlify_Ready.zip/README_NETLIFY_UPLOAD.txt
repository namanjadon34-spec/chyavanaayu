NETLIFY UPLOAD STEPS

1. Extract this ZIP file.
2. Open https://app.netlify.com/drop
3. Drag and drop the extracted folder itself, not the ZIP.
4. Make sure index.html is directly inside the uploaded folder.

This package is Netlify-ready. It includes:
- index.html at root
- separate HTML pages
- _redirects for clean URLs
- netlify.toml for static hosting
- 404.html fallback page
